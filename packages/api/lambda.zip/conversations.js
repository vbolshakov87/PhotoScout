import { createRequire } from 'module'; const require = createRequire(import.meta.url);

// src/lib/dynamo.ts
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  PutCommand,
  QueryCommand,
  GetCommand,
  DeleteCommand,
  UpdateCommand
} from "@aws-sdk/lib-dynamodb";
var client = new DynamoDBClient({});
var docClient = DynamoDBDocumentClient.from(client);
var MESSAGES_TABLE = process.env.MESSAGES_TABLE || "photoscout-messages";
var CONVERSATIONS_TABLE = process.env.CONVERSATIONS_TABLE || "photoscout-conversations";
var PLANS_TABLE = process.env.PLANS_TABLE || "photoscout-plans";
async function getConversationMessages(visitorId, conversationId) {
  const result = await docClient.send(
    new QueryCommand({
      TableName: MESSAGES_TABLE,
      IndexName: "conversationId-index",
      KeyConditionExpression: "conversationId = :cid",
      FilterExpression: "visitorId = :vid",
      ExpressionAttributeValues: {
        ":cid": conversationId,
        ":vid": visitorId
      },
      ScanIndexForward: true
    })
  );
  return result.Items || [];
}
async function listConversations(visitorId, limit = 20, cursor) {
  const result = await docClient.send(
    new QueryCommand({
      TableName: CONVERSATIONS_TABLE,
      KeyConditionExpression: "visitorId = :vid",
      ExpressionAttributeValues: {
        ":vid": visitorId
      },
      ScanIndexForward: false,
      Limit: limit,
      ...cursor && { ExclusiveStartKey: JSON.parse(Buffer.from(cursor, "base64").toString()) }
    })
  );
  const items = result.Items || [];
  const nextCursor = result.LastEvaluatedKey ? Buffer.from(JSON.stringify(result.LastEvaluatedKey)).toString("base64") : void 0;
  return {
    items,
    nextCursor,
    hasMore: !!result.LastEvaluatedKey
  };
}
async function getConversation(visitorId, conversationId) {
  const result = await docClient.send(
    new GetCommand({
      TableName: CONVERSATIONS_TABLE,
      Key: {
        visitorId,
        conversationId
      }
    })
  );
  return result.Item || null;
}
async function deleteConversation(visitorId, conversationId) {
  await docClient.send(
    new DeleteCommand({
      TableName: CONVERSATIONS_TABLE,
      Key: {
        visitorId,
        conversationId
      }
    })
  );
}

// src/handlers/conversations.ts
var corsHeaders = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};
async function handler(event) {
  if (event.requestContext.http.method === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders, body: "" };
  }
  try {
    const visitorId = event.queryStringParameters?.visitorId;
    if (!visitorId) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: "Missing visitorId" })
      };
    }
    const path = event.rawPath;
    const method = event.requestContext.http.method;
    if (path === "/api/conversations" && method === "GET") {
      const limit = parseInt(event.queryStringParameters?.limit || "20");
      const cursor = event.queryStringParameters?.cursor;
      const result = await listConversations(visitorId, limit, cursor);
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify(result)
      };
    }
    const conversationMatch = path.match(/^\/api\/conversations\/([^/]+)$/);
    if (conversationMatch && method === "GET") {
      const conversationId = conversationMatch[1];
      const [conversation, messages] = await Promise.all([
        getConversation(visitorId, conversationId),
        getConversationMessages(visitorId, conversationId)
      ]);
      if (!conversation) {
        return {
          statusCode: 404,
          headers: corsHeaders,
          body: JSON.stringify({ error: "Conversation not found" })
        };
      }
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({ conversation, messages })
      };
    }
    if (conversationMatch && method === "DELETE") {
      const conversationId = conversationMatch[1];
      await deleteConversation(visitorId, conversationId);
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({ success: true })
      };
    }
    return {
      statusCode: 404,
      headers: corsHeaders,
      body: JSON.stringify({ error: "Not found" })
    };
  } catch (error) {
    console.error("Conversations error:", error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
}
export {
  handler
};
